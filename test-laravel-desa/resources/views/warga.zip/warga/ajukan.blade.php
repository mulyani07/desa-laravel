@extends('layouts.warga')

@section('content')

<div class="container-warga">

    {{-- STEP INDICATOR --}}
    <div class="step-wrapper">
        <div class="step active"><span>1</span>
            <p>Pilih Jenis</p>
        </div>
        <div class="line active"></div>
        <div class="step"><span>2</span>
            <p>Isi Data</p>
        </div>
        <div class="line"></div>
        <div class="step"><span>3</span>
            <p>Konfirmasi</p>
        </div>
    </div>

    <div class="card-warga modern-card">

        <form method="POST" action="/ajukan-surat" enctype="multipart/form-data" id="formWizard">
            @csrf

            {{-- ================= STEP 1 ================= --}}
            <div class="step-content active" id="step-1">
                <h3>Pilih Jenis Surat</h3>

                <div class="jenis-grid">
                    @foreach($jenisSurat as $j)
                    <label class="jenis-card">
                        <input type="radio" name="jenis" value="{{ $j->nama_jenis }}" required>
                        <i class="fas fa-file-alt"></i>
                        <span>{{ $j->nama_jenis }}</span>
                    </label>
                    @endforeach
                </div>

                <div class="form-action">
                    <button type="button" class="btn-primary" onclick="nextStep(1)">Lanjut</button>
                </div>
            </div>


            {{-- ================= STEP 2 ================= --}}
            <div class="step-content" id="step-2">
                <h3>Isi Data</h3>

                <div class="form-group">
                    <label>Nama Pemohon</label>
                    <input type="text" name="nama" value="{{ auth()->user()->name }}" readonly>
                </div>

                <div class="file-grid">

                    <div class="file-card">
                        <label>KTP</label>
                        <input type="file" name="dok_ktp" accept=".jpg,.jpeg,.png,.pdf">
                        <small class="file-info">Maksimal 1 MB • JPG, PNG, PDF</small>
                    </div>

                    <div class="file-card">
                        <label>KK</label>
                        <input type="file" name="dok_kk" accept=".jpg,.jpeg,.png,.pdf">
                        <small class="file-info">Maksimal 1 MB • JPG, PNG, PDF</small>
                    </div>

                    <div class="file-card">
                        <label>Surat Pengantar</label>
                        <input type="file" name="dok_pengantar" accept=".jpg,.jpeg,.png,.pdf">
                        <small class="file-info">Maksimal 1 MB • JPG, PNG, PDF</small>
                    </div>

                </div>

                <div class="form-action">
                    <button type="button" class="btn-secondary" onclick="prevStep(2)">Kembali</button>
                    <button type="button" class="btn-primary" onclick="nextStep(2)">Lanjut</button>
                </div>
            </div>


            {{-- ================= STEP 3 ================= --}}
            <div class="step-content" id="step-3">
                <h3>Konfirmasi Data</h3>

                <div class="confirm-box">
                    <p><b>Nama:</b> <span id="confirmNama"></span></p>
                    <p><b>Jenis Surat:</b> <span id="confirmJenis"></span></p>
                </div>

                <div class="form-action">
                    <button type="button" class="btn-secondary" onclick="prevStep(3)">Kembali</button>
                    <button type="submit" class="btn-primary">Kirim Pengajuan</button>
                </div>
            </div>

        </form>

    </div>
</div>

@endsection
<script>
    function nextStep(step) {
        document.getElementById('step-' + step).classList.remove('active');
        document.getElementById('step-' + (step + 1)).classList.add('active');

        updateStep(step + 1);

        // isi konfirmasi
        if (step === 2) {
            document.getElementById('confirmNama').innerText =
                document.querySelector('[name=nama]').value;

            let jenis = document.querySelector('[name=jenis]:checked');
            document.getElementById('confirmJenis').innerText =
                jenis ? jenis.value : '-';
        }
    }

    function prevStep(step) {
        document.getElementById('step-' + step).classList.remove('active');
        document.getElementById('step-' + (step - 1)).classList.add('active');

        updateStep(step - 1);
    }

    function updateStep(current) {
        let steps = document.querySelectorAll('.step');
        let lines = document.querySelectorAll('.line');

        steps.forEach((s, i) => {
            s.classList.remove('active', 'done');
            if (i + 1 < current) s.classList.add('done');
            else if (i + 1 === current) s.classList.add('active');
        });

        lines.forEach((l, i) => {
            l.classList.remove('active');
            if (i < current - 1) l.classList.add('active');
        });
    }
</script>
<script>
    document.querySelectorAll('input[type="file"]').forEach(input => {
        input.addEventListener('change', function() {
            let file = this.files[0];
            if (file) {
                let sizeMB = file.size / 1024 / 1024;

                if (sizeMB > 1) {
                    alert('File maksimal 1 MB!');
                    this.value = "";
                }
            }
        });
    });
</script>