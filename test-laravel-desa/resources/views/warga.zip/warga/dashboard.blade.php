@extends('layouts.warga')

@section('content')

<!-- HERO SECTION -->
<section class="hero">
    <div class="hero-content">
        <h1>Selamat Datang di Desa Bloro</h1>
        <p>Website Desa Asri, Sejuk, Damai dan Penuh Kebahagiaan</p>

        @auth
        <a href="/ajukan-surat" class="btn-hero">Ajukan Surat →</a>
        @else
        <a href="/login" class="btn-hero">Login untuk Full Fitur →</a>
        @endauth
    </div>
</section>

<!-- FEATURES -->
<section class="features">
    <div class="feature-box">
        <i class="fas fa-file-alt"></i>
        <h3>Layanan Surat Online</h3>
        <p>Ajukan surat dengan mudah tanpa harus ke kantor desa.</p>
    </div>

    <div class="feature-box">
        <i class="fas fa-clock"></i>
        <h3>Proses Cepat</h3>
        <p>Pelayanan efisien dan transparan.</p>
    </div>

    <div class="feature-box">
        <i class="fas fa-users"></i>
        <h3>Data Terintegrasi</h3>
        <p>Data aman dan terkelola dengan baik.</p>
    </div>
</section>

<!-- ================= BERITA ================= -->
<section class="container-warga">

    <div class="section-header">
        <h3><i class="fas fa-newspaper"></i> Berita Terbaru</h3>
        <a href="/berita" class="lihat-semua">Lihat Semua →</a>
    </div>

    <div class="berita-grid">

        @forelse($berita as $b)
        <div class="berita-card">

            {{-- ✅ CLOUDINARY --}}
            @if($b->gambar)
                <img src="{{ $b->gambar }}" alt="berita">
            @else
                <img src="https://via.placeholder.com/400x200?text=No+Image" alt="no image">
            @endif

            <div class="berita-content">
                <div class="berita-date">
                    {{ \Carbon\Carbon::parse($b->created_at)->format('d M Y') }}
                </div>

                <h4>{{ $b->judul }}</h4>

                <p>
                    {{ \Illuminate\Support\Str::limit(strip_tags($b->isi), 80) }}
                </p>

                <a href="/berita/{{ $b->id }}" class="btn-primary btn-sm">
                    Baca →
                </a>
            </div>

        </div>
        @empty
            <p>Belum ada berita.</p>
        @endforelse

    </div>

</section>

<!-- ================= MAP ================= -->
<section class="container-warga">

    <div class="section-header">
        <h3><i class="fas fa-map-marker-alt"></i> Lokasi Desa</h3>
    </div>

    <div class="map-box">
        <iframe
            src="https://www.google.com/maps?q=Desa+Bloro&output=embed"
            width="100%"
            height="300"
            style="border:0; border-radius:12px;"
            allowfullscreen>
        </iframe>
    </div>

</section>

@endsection