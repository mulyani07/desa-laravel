@extends('layouts.warga')

@section('content')

<div class="container-warga">

    <div class="card-warga berita-detail">

        {{-- JUDUL --}}
        <h2 class="berita-title">{{ $berita->judul }}</h2>

        {{-- TANGGAL --}}
        <p class="berita-date">
            <i class="fas fa-calendar-alt"></i>
            Dipublikasikan {{ \Carbon\Carbon::parse($berita->created_at)->format('d M Y') }}
        </p>

        {{-- GAMBAR --}}
        @if($berita->gambar)
            <img src="{{ $berita->gambar }}" class="berita-detail-img">
        @endif

        {{-- ISI --}}
        <div class="berita-text">
            {!! nl2br(e($berita->isi)) !!}
        </div>

        {{-- BUTTON --}}
        <a href="/berita" class="btn-primary mt-3">
            ← Kembali ke Berita
        </a>

    </div>

</div>

@endsection